import{r as i}from"./index-CdM2w1sX.js";const t=i("PushNotifications",{});export{t as PushNotifications};
