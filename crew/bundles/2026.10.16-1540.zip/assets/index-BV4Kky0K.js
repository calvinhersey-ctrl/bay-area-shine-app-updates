import{r as i}from"./index-L8rucRu1.js";const t=i("PushNotifications",{});export{t as PushNotifications};
