import{r as i}from"./index-s98RRQI1.js";const t=i("PushNotifications",{});export{t as PushNotifications};
