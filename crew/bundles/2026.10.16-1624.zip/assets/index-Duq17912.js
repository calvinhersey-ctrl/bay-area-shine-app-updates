import{r as i}from"./index-Is4uM_QX.js";const t=i("PushNotifications",{});export{t as PushNotifications};
