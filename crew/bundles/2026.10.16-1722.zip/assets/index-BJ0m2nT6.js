import{r as i}from"./index-ecfLDFhA.js";const t=i("PushNotifications",{});export{t as PushNotifications};
