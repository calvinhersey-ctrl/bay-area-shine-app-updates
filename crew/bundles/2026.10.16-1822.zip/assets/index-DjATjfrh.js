import{r as i}from"./index-Bd5HO0t8.js";const t=i("PushNotifications",{});export{t as PushNotifications};
