import{r as i}from"./index-DvEgqbQl.js";const t=i("PushNotifications",{});export{t as PushNotifications};
