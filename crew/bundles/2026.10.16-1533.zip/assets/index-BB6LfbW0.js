import{r as i}from"./index-oFJMrbHY.js";const t=i("PushNotifications",{});export{t as PushNotifications};
