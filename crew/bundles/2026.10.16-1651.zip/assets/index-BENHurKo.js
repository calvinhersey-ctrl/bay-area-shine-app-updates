import{r as i}from"./index-DnzRaqUR.js";const t=i("PushNotifications",{});export{t as PushNotifications};
