import{r as i}from"./index-HKVLF2M7.js";const t=i("PushNotifications",{});export{t as PushNotifications};
