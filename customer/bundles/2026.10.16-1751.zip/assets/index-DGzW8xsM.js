import{r as i}from"./index-ClGl2CEx.js";const t=i("PushNotifications",{});export{t as PushNotifications};
