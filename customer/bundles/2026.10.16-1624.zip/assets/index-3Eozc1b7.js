import{r as i}from"./index-Dh2l63sS.js";const t=i("PushNotifications",{});export{t as PushNotifications};
