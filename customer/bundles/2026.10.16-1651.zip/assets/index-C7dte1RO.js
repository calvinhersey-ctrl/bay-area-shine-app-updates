import{r as i}from"./index-BqXL6CvL.js";const t=i("PushNotifications",{});export{t as PushNotifications};
