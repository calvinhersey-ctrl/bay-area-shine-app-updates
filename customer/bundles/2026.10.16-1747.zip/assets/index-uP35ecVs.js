import{r as i}from"./index-aDsoUS17.js";const t=i("PushNotifications",{});export{t as PushNotifications};
