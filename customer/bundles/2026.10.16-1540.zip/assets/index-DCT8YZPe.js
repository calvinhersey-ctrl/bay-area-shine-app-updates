import{r as i}from"./index-DmgSfgEV.js";const t=i("PushNotifications",{});export{t as PushNotifications};
