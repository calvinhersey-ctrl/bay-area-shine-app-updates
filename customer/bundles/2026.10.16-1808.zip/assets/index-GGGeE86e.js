import{r as i}from"./index-QLZwhftq.js";const t=i("PushNotifications",{});export{t as PushNotifications};
