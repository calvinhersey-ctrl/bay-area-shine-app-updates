import{r as i}from"./index-ByLCH1TD.js";const t=i("PushNotifications",{});export{t as PushNotifications};
