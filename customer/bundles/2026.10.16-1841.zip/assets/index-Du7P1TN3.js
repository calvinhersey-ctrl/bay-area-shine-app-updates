import{r as i}from"./index-CmpzcU46.js";const t=i("PushNotifications",{});export{t as PushNotifications};
