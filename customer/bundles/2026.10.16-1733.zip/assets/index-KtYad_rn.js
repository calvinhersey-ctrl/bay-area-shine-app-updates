import{r as i}from"./index-D--pFWsS.js";const t=i("PushNotifications",{});export{t as PushNotifications};
